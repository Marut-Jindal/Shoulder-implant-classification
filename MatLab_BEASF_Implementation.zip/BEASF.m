function [E, map] = BEASF(I,gamma)

%%%% Documentation %%%%
%-----------------------------------------------------------------------------------------------
% This Function corresponds to the BEASF Algorithm corresponding to the research article
% "Image enhancement using Bi-Histogram Equalization with adaptive sigmoid functions" 
%%%%	Attributes   %%%%%%
% gamma is a value normally between [0,1] meaning 1 more enhancement and 0 no enhancement.
% I variable is the Image 
%%%    Return Values %%%%%
% E is the Output Image
% map is the mapping vector for benchmark purposes.
%-----------------------------------------------------------------------------------------------


%Calculate Image Mean
m=mean2(I);
m=int32(m);

%Compute Probability Density Function
h = imgpdf(I);

%Calculate lower and upper histograms
lh = subhist(h,0,m,true);
uh = subhist(h,m,255,true);

%Get Cumulative Distribution Functions (CDF)
lc = CDF(lh);
uc = CDF(uh);

%Find x | CDF(x) = 0.5
halfLow = 0;
for i=0:m
    if lc(i+1) > 0.5
        halfLow=i;
        break;
    end
end
halfUp = 0;
for i=m:255
    if uc(i+1) > 0.5
        halfUp=i;
        break;
    end
end

%Sigmoid CDF creation
tonesLow = 0:1:m;
xLow= double(5.0*(tonesLow-halfLow))/double(m); %shift and scale intensity x to place sigmoid [-2.5,2.5]
%Lower Sigmoid
sLow = 1./(1+exp(-gamma*xLow));

tonesUp = m:1:255;
xUp= double(5*(tonesUp-halfUp))/double((255-m)); %shift and scale intensity x to place sigmoid [-2.5,2.5]
%Upper Sigmoid
sUp = 1./(1+exp(-gamma*xUp));

for i=0:m
    map(i+1) = int32(m*sLow(i+1));
end

min=map(1);
max=map(m+1);
for i=0:m
    map(i+1) = int32((double(m)/double( max-min) )*(map(i+1)-min));
end
for i=m+1:255
    map(i+1) = int32(m + (255-m)*sUp(i-m));
end

min = map(m+2);
max = map(256);
for i=m+1:255
    map(i+1) = double((255-m))*double((map(i+1)- min))/double((max-min)) + double(m) ;
end

E = I;
E(:,:) = map(I(:,:)+1);