% Author: Edgar F. Arriaga Garcia (eferagarox@gmail.com).
%
% subhist calculates the subhistogram given between [min,max] taking as input histogram h.
% Input parameters:
%    h: Input histogram, passed as a vector 1x256
%	 min: minimum value for clipping the histogram h
%	 max: maximum value for clipping the histogram h
%	 norm: boolean that determines if it will normalize the subhistogram. (Turn it into a pdf)
% Ouput parameters:
%    hi: Output Subhistogram
%
% Usage:
%    I    = imread('tire.tif');
%	 h = imhist(I)
%    subh = subhist(h,30,70,true);
%    plot(subh);

%Get a histogram subhistogram from [min,max]
function hi = subhist(h,min,max,norm)
min = int32(min+1);
max = int32(max+1);
hi=zeros(size(h));
total = 0;
for i=min:max
   total = total + h(i);
   hi(i) =  h(i);
end
if norm == true
    for i=min:max
        hi(i) = hi(i)/total;
    end
end
