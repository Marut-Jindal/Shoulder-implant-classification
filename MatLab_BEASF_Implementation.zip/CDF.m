%Input H is a histogram not necesarily normalized
function cdf = CDF(H)
    cdf(1) = H(1);
    for i=2:length(H)
        cdf(i) = cdf(i-1)+H(i);
    end
end