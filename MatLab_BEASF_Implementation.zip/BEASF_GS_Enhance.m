% Gray Scale Image Enhancer %
%Additional Notes: 
%1) You can unncomment rgb2gray line to be able to read a color image and
%turn it into gray scale to make the enhancement.
%3) You can also enhance color images but you need to apply the algorithm
%on their luminance and chrominance components.
%
%Usage example: BEASF_GS_Enhance("girl.jpg","enhanced_girl.jpg")

function BEASF_GS_Enhance(inputfile, outfile)

%O = rgb2gray(imread(file));
O = imread(inputfile);
beasf = BEASF(O,1);
imwrite(beasf,outfile)
end


