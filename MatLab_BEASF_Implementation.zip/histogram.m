function H=histogram(I)
[rows cols] = size(I);
H = zeros(1,256);
for i=1:rows
    for j=1:cols
        H(I(i,j)+1) = H(I(i,j)+1)+1;
    end
end